<?php
/*
Plugin Name:  firsttheme metaboxes
Plugin URI:
Description:  Adding Metaboxes for firsttheme
Version:      1.0.0
Author:       Jared Hodgkins
Author URI:   https://talentedsigner.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  firsttheme-metaboxes
Domain Path:  /languages
*/

if( !defined('WPINC')) {
  die;
}

include_once('includes/metaboxes.php');
include_once('includes/enqueue-assets.php');
